<?php

require  '../vendor/autoload.php';
require  '../lib/mysql.php';

$app = new \Slim\App; 
 
$app->get('/users', 'get_users');
 
$app->run();
 
function get_users() {
    $db = connect_db();
    $sql = "SELECT * FROM users";
    $exe = $db->query($sql);
    $data = $exe->fetch_all(MYSQLI_ASSOC);
    $db = null;
    echo json_encode($data);
}
 
$app->run();