<?php
 
function connect_db() {
    $server = 'localhost'; 
    $user = 'root';
    $pass = '';
    $database = 'web_service'; 
    $connection = new mysqli($server, $user, $pass, $database);
 
    return $connection;
}
?>