<?php
	class Database {

		public static function connect() {
				
			$db = new mysqli('localhost','root','','auth');
			
			if ( mysqli_connect_errno() ) {
				printf("Connection failed: %s", mysqli_connect_error());
				exit();
			}
			return $db;
		}
	}	
	
?>