<?php error_reporting(0); require_once 'include/class.autoload.php'; require_once 'include/class.user.php'; ?>
<?php

$input = new Auto;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	$username = $input->check_input($_POST['username']);
	$password = $input->check_input($_POST['password']);
	
	$user = new User;
	$query = $user->login($username,$password,'admin');
	if($query === TRUE){
		$user->redirect('index.php');
	}
	
}
?>
<!DOCTYPE html>
	<html class="no-focus">
    <head>
		<meta charset="utf-8">
        <title>ChampUI</title>
        <meta name="author" content="Champ Decay">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700">
        <link rel="stylesheet" id="css-main" href="<?php echo $champ->assets_folder; ?>/css/oneui.min.css">
		<link rel="stylesheet" id="css-main" href="<?php echo $champ->assets_folder; ?>/css/style.css">
    </head>
    <body>
        <div class="content overflow-hidden">
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
                    <div class="block block-themed animated fadeIn">
                        <div class="block-header bg-primary">
                            <ul class="block-options">
                                <li><a href="<?php echo $champ->admin_url; ?>/forget.php">Forgot Password?</a></li>
                                <li><a href="<?php echo $champ->admin_url; ?>/register.php" data-toggle="tooltip" data-placement="left" title="New Account"><i class="si si-plus"></i></a></li>
                            </ul>
                            <h3 class="block-title">Login</h3>
                        </div>
                        <div class="block-content block-content-full block-content-narrow">
                            <h1 class="h2 font-w600 push-30-t push-5">OneUI</h1>
                            <p>Welcome, please login.</p>
                            <form class="form-horizontal" method="post">
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <div class="form-material form-material-primary floating">
                                            <input class="form-control" type="text" id="username" name="username">
                                            <label>Username</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <div class="form-material form-material-primary floating">
                                            <input class="form-control" type="password" id="password" name="password">
                                            <label>Password</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <label class="css-input switch switch-sm switch-primary">
                                            <input type="checkbox" id="remember-me" name="remember-me"><span></span> Remember Me?
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <button class="btn btn-block btn-primary" name="login" type="submit"><i class="si si-login pull-right"></i> Log in</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="push-10-t text-center animated fadeInUp">
            <small class="text-muted font-w600"><span class="js-year-copy"></span> &copy; ChampUI 1.0</small>
        </div>
        <script src="<?php echo $champ->assets_folder; ?>/js/jquery.min.js"></script>
        <script src="<?php echo $champ->assets_folder; ?>/js/bootstrap.min.js"></script>
        <script src="<?php echo $champ->assets_folder; ?>/js/app.js"></script>
    </body>
</html>