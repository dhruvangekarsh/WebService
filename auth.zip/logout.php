<?php error_reporting(0); require_once 'include/class.autoload.php'; require_once 'include/class.user.php'; ?>
<?php
	$logout = new User;
	if(!$logout->leave() == FALSE){
		$logout->redirect('login.php');
	}
?>