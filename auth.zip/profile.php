<?php require_once 'include/class.autoload.php'; require_once 'include/class.user.php'; ?>
<?php

$input = new Auto;
$user = new User;

if(!$user->is_loggedin() === TRUE){
	$user->redirect('login.php');
}
echo $_SESSION['user'];
?>
<ul>
	<li><a href="<?php echo $champ->admin_url; ?>">Home</a></li>
	<li><a href="<?php echo $champ->admin_url; ?>">Profile</a></li>
	<li><a href="<?php echo $champ->admin_url; ?>">Family Listing</a></li>
	<li><a href="<?php echo $champ->admin_url; ?>">Find Me</a></li>
	<li><a href="<?php echo $champ->admin_url; ?>">Matrimonial</a></li>
	<li><a href="<?php echo $champ->admin_url; ?>/logout.php">Logout</a></li>
</ul>
