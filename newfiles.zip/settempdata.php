<?php
	
	$date = $_POST['date'];
	$time = $_POST['time'];
	
	if(!isset($_COOKIE['tempData'])) {
		$data[$date] = $time;
		setcookie('tempData', serialize($data));  	 
	} else {
		$fetch_data = unserialize($_COOKIE['tempData']); 
		$dates = array_keys($fetch_data);
		if (in_array($date, $dates)){
			echo '<script>alert("Already Exists!");</script>';
			exit();
		}
		else{
			$fetch_data[$date] = $time;
			setcookie('tempData', serialize($fetch_data));
		}
	}
	
	// setcookie('tempData', serialize($data));   Set Array in Cookie
	
	// $data = unserialize($_COOKIE['test']);  Retrive Associative Array from Cookie
	
	// print_r(array_keys($a));Get Array Keys [Dates]
	
	function showData(){
		if(isset($_COOKIE['tempData'])) {
			$tempdata = unserialize($_COOKIE['tempData']); 
			print_r($tempdata);	
		}
	}
	
	showData();
	
?>

