<?php require_once 'include/class.autoload.php'; require_once 'include/class.user.php'; ?>
<?php

$input = new Auto;
$user = new User;

if(!$user->is_loggedin() === TRUE){
	$user->redirect('login.php');
}
echo $_SESSION['user'];

?>
<ul>
	<li><a href="<?php echo $champ->admin_url; ?>/profile.php">Profile</a></li>
	<li><a href="<?php echo $champ->admin_url; ?>/logout.php">Logout</a></li>
</ul>