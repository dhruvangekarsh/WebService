<?php
$servername = "localhost";
$username 	= "root";
$password 	= "";

try {
    $conn = new PDO("mysql:host=$servername;dbname=one", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully";
}
catch(PDOException $e){
    echo "Connection failed: " . $e->getMessage();
}

function add($title,$content){
	try {
		global $conn;
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$stmt = $conn->prepare("INSERT INTO posts (title, content) VALUES (:title, :content)");
		$stmt->bindParam(":title", $title); 
		$stmt->bindParam(":content", $content); 
		$stmt->execute();
		echo "New record created successfully";
	}
	catch(PDOException $e){
		$e->getMessage();
	}
	$conn = null;
}
if(isset($_POST['submit'])){
	$title = $_POST['title'];
	$content = $_POST['content'];
	add($title,$content);
}
?>

<form method="POST">
	<input type="text" name="title" placeholder="Title" />
	<input type="text" name="content" placeholder="content" />
	<input type="submit" name="submit"/>
</form>