<?php
//Create and configure Slim app

require 'vendor/autoload.php';

$app = new Slim\App();

// Define app routes
/*$app->get('/hello/{name}', function ($request, $response, $args) {
    return $response->write("Hello " . $args['name']);
});

$app->get('/', function ($req,  $res, $args) {
    return $res->withStatus(400)->write('Bad Request');
});*/

/*$app->get('/', function ($req,  $res, $args) {
    $myvar1 = $req->getParam('myvar'); //checks both _GET and _POST [NOT PSR-7 Compliant]
    $myvar2 = $req->getParsedBody()['myvar']; //checks _POST  [IS PSR-7 compliant]
    $myvar3 = $req->getQueryParams()['myvar']; //checks _GET [IS PSR-7 compliant]
});*/

/*$app->get('/', function ($req, $res, $args) {
  return $res->withStatus(302)->withHeader('Location', 'your-new-uri');
});

$app->get('/hello/{name}', function ($request, $response, $args) {
    return $response->write("Hello " . $args['name']);
});

// optional segment:
$app->get('/news[/{year}]', function ($request, $response, $args) {
    return $response->write("News " . $args['year']);
});
*/

$app->get('/', function ($request, $response, $args) {
    $url = $this->router->pathFor('home');
    $response->write("<a href='$url'>Home</a>");
    return $response;
})->setName('home');


// Run app
$app->run();