<?php
	class Auto {
		public  $name               = '',
            	$version            = '',
				$author             = '',
				$title              = '',
				$description        = '',
				$admin_url			= '',
				$site_url			= '',
				$assets_folder      = '';
			
		public function __construct($name = '', $version = '', $admin_url = '', $site_url = '', $assets_folder = '') {
			$this->name                 = $name;
			$this->version              = $version;
			$this->admin_url	        = $admin_url;
			$this->site_url		        = $site_url;
			$this->assets_folder        = $assets_folder;
		}
			
		public function check_input($data) {
		  	$data = trim($data);
		  	$data = stripslashes($data);
		  	$data = htmlspecialchars($data);
		  	return $data;
		}
			
	}	
	
	$champ = new Auto('ChampUI','1.01','http://localhost/admin/auth','','http://localhost/admin/auth/assets');
	
?>