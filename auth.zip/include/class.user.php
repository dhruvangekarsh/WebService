<?php

	require 'class.database.php';

	class User {
		
		public function __construct(){
			$db = Database::connect();
			$this->con = $db;
					
			date_default_timezone_set("Asia/Kolkata");	
			$time = date('Y-m-d H:i:s' ,time());
			$this->now = $time;
			
			session_start();
			
		}
		
		public function registration($username,$email,$password, $type){
			$password = md5($password);
			$query = $this->con->query("INSERT INTO $type(username,email,password,created)VALUES('$username','$email','$password','$this->now')") or die($this->con->error);
			return TRUE;
		}
		
		public function login($user,$password,$type){
			$password = md5($password);
			$query = $this->con->query('SELECT * FROM '.$type.' WHERE (username = "'.$user.'" OR email = "'.$user.'") AND password = "'.$password.'"') or die($this->con->error);
			$data = $query->fetch_array();
			print_r($data);
			if($query->num_rows == 1){
				$_SESSION['user'] = $data[0];
				return TRUE;
			}
		}
		
		public function getData($table){
			$query = $this->con->query("SELECT * FROM $table") or die($this->con->error);
			return $query;
		}
		
		public function is_loggedin(){
			if(isset($_SESSION['user'])){return true;}
		}
		
		public function redirect($url){
			header('location:'.$url);
		}
		
		public function leave(){
			unset($_SESSION['user']);
			session_destroy();
			return true;
		}
		
	}
?>