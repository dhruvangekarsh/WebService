<?php

include '../cms/db_info.php';

$query = mysql_query("SELECT * FROM listings");

while($data = mysql_fetch_assoc){
	echo $data['address'];
}



$address = "2735, West, 5th Avenue, Vancouver, BC";
$address = str_replace(' ', '', $address);
$url = "http://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&region=canada";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$response = curl_exec($ch);
curl_close($ch);
$response_a = json_decode($response);
echo $lat = $response_a->results[0]->geometry->location->lat;
echo "<br />";
echo $long = $response_a->results[0]->geometry->location->lng;

?>



<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>Marker Clustering</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
  </head>
  <body>
    <div id="map"></div>
    <script>

      function initMap() {

  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 3,
    center: {
      lat: 20,
      lng: -80
    }
  });
  var infoWin = new google.maps.InfoWindow();
  
  var markers = locations.map(function(location, i) {
    var marker = new google.maps.Marker({
      position: location
    });
    google.maps.event.addListener(marker, 'click', function(evt) {
      infoWin.setContent(location.info);
      infoWin.open(map, marker);
    })
    return marker;
  });

  // markerCluster.setMarkers(markers);
  // Add a marker clusterer to manage the markers.
  var markerCluster = new MarkerClusterer(map, markers, {
    imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'
  });

}
var locations = [{
  lat: <?php echo $lat; ?>,
  lng: <?php echo $long; ?>,
  info: "<h3>marker</h3><img src='http://ekarsh-projects.com/mysat/listings/442/1.jpg' />"
}, {
  lat: -19.85758,
  lng: -43.9668,
  info: "<h3>marker</h3><img src='http://ekarsh-projects.com/mysat/listings/442/1.jpg' />"
}, {
  lat: -18.24587,
  lng: -43.59613,
  info: "<h3>marker</h3><img src='http://ekarsh-projects.com/mysat/listings/442/1.jpg' />"
}, {
  lat: -20.46427,
  lng: -45.42629,
  info: "<h3>marker</h3><img src='http://ekarsh-projects.com/mysat/listings/442/1.jpg' />"
}, {
  lat: -20.37817,
  lng: -43.41641,
  info: "<h3>marker</h3><img src='http://ekarsh-projects.com/mysat/listings/442/1.jpg' />"
}, {
  lat: -20.09749,
  lng: -43.48831,
  info: "<h3>marker</h3><img src='http://ekarsh-projects.com/mysat/listings/442/1.jpg' />"
}, {
  lat: -21.13594,
  lng: -44.26132,
  info: "<h3>marker</h3><img src='http://ekarsh-projects.com/mysat/listings/442/1.jpg' />"
}, ];

google.maps.event.addDomListener(window, "load", initMap);

    </script>
    <script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js">
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBFQ6Lzwj8aFfGseoPOoUthVHsYQlGlsJI&callback=initMap">
    </script>
  </body>
</html>