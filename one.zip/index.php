<?php

require 'vendor/autoload.php';

$app = new Slim\App();

/*$app->get('/hello/{name}', function ($request, $response, $args) {
    return $response->write("Hello, " . $args['name']);
});*/

$app->add(function (Request $request, Response $response, $next) {
    $request = $request->withAttribute('abc', 'def');
    return $next($request, $response);
});

$app->run();

$method = $request->getMethod();