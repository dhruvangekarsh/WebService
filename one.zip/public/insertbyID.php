<?php

require  '../vendor/autoload.php';
require  '../lib/mysql.php';

$app = new \Slim\App; 
 
$app->get('/employee/{id}', function($request, $response, $args) {
    get_employee_id($args['id']);
});
 
$app->run();
 
function get_employee_id($employee_id) {
    $db = connect_db();
    $sql = "SELECT * FROM users WHERE id = '$employee_id'";
    $exe = $db->query($sql);
    $data = $exe->fetch_all(MYSQLI_ASSOC);
    $db = null;
    echo json_encode($data);
}
 
$app->run();