<?php require_once 'include/class.autoload.php'; require_once 'include/class.user.php'; ?>

<?php

$input = new Auto;
$error = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	$username = $input->check_input($_POST['username']);
	$email = $input->check_input($_POST['email']);
	$password = $input->check_input($_POST['password']);
	
	if (empty($username)) {
    	$error['username'] = "Username is required";
	} 
	else if (!preg_match("/^[a-zA-Z ]*$/",$username)) {
    	$error['username'] = "Only letters and white space allowed";
  	}
	
	if (empty($email)) {
    	$error['email'] = "Email is required";
	} 
	else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    	$error['email'] = "Invalid email format";
    }
	
	if (empty($password)) {
    	$error['password'] = "Password is required";
	} 
	else if(!preg_match('/^[a-zA-z0-9]{8,20}+$/', $password)) {
		$error['password'] = 'Invalid Password !';
	}
	
	if(count($error) === 0){
		$user = new User;
		$query = $user->registration($username,$email,$password,'admin');
		if($query === TRUE){
			$user->redirect('login.php');
		}
	}
	
}
?>

<!DOCTYPE html>
	<html>
    <head>
		<meta charset="utf-8">
        <title>ChampUI</title>
        <meta name="author" content="Champ Decay">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700">
        <link rel="stylesheet" id="css-main" href="<?php echo $champ->assets_folder; ?>/css/oneui.min.css">
		<link rel="stylesheet" id="css-main" href="<?php echo $champ->assets_folder; ?>/css/style.css">
    </head>
    <body>
        <div class="content overflow-hidden">
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
                    <div class="block block-themed animated fadeIn">
                        <div class="block-header bg-success">
                            <ul class="block-options">
                                <li><a href="#" data-toggle="modal" data-target="#modal-terms">View Terms</a></li>
                                <li><a href="base_pages_login.html" data-toggle="tooltip" data-placement="left" title="Log In"><i class="si si-login"></i></a></li>
                            </ul>
                            <h3 class="block-title">Register</h3>
                        </div>
                        <div class="block-content block-content-full block-content-narrow">
                            <h1 class="h2 font-w600 push-30-t push-5">OneUI</h1>
                            <p>Please fill the following details to create a new account.</p>
                            <form class="form-horizontal" method="POST">
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <div class="form-material form-material-success">
                                            <input class="form-control" type="text" id="username" name="username" placeholder="Please enter a username">
                                            <label>Username</label>
											<span class="error"><?php echo $error['username']; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <div class="form-material form-material-success">
                                            <input class="form-control" type="email" id="email" name="email" placeholder="Please provide your email">
                                            <label>Email</label>
											<span class="error"><?php echo $error['email']; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <div class="form-material form-material-success">
                                            <input class="form-control" type="password" id="password" name="password" placeholder="Choose a strong password..">
                                            <label>Password</label>
											<span class="error"><?php echo $error['password']; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <label class="css-input switch switch-sm switch-success">
                                            <input type="checkbox" id="terms" name="terms"><span></span> I agree with terms &amp; conditions
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12 col-sm-6 col-md-5">
                                        <button class="btn btn-block btn-success" type="submit" name="register"><i class="fa fa-plus pull-right"></i> Sign Up</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="push-10-t text-center animated fadeInUp">
            <small class="text-muted font-w600"><span class="js-year-copy"></span> &copy; OneUI 1.0</small>
        </div>
        <div class="modal fade" id="modal-terms" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-popout">
                <div class="modal-content">
                    <div class="block block-themed block-transparent remove-margin-b">
                        <div class="block-header bg-primary-dark">
                            <ul class="block-options">
                                <li>
                                    <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                                </li>
                            </ul>
                            <h3 class="block-title">Terms &amp; Conditions</h3>
                        </div>
                        <div class="block-content">
                            <p>Dolor posuere proin blandit accumsan senectus netus nullam curae, ornare laoreet adipiscing luctus mauris adipiscing pretium eget fermentum, tristique lobortis est ut metus lobortis tortor tincidunt himenaeos habitant quis dictumst proin odio sagittis purus mi, nec taciti vestibulum quis in sit varius lorem sit metus mi.</p>
                            <p>Dolor posuere proin blandit accumsan senectus netus nullam curae, ornare laoreet adipiscing luctus mauris adipiscing pretium eget fermentum, tristique lobortis est ut metus lobortis tortor tincidunt himenaeos habitant quis dictumst proin odio sagittis purus mi, nec taciti vestibulum quis in sit varius lorem sit metus mi.</p>
                            <p>Dolor posuere proin blandit accumsan senectus netus nullam curae, ornare laoreet adipiscing luctus mauris adipiscing pretium eget fermentum, tristique lobortis est ut metus lobortis tortor tincidunt himenaeos habitant quis dictumst proin odio sagittis purus mi, nec taciti vestibulum quis in sit varius lorem sit metus mi.</p>
                            <p>Dolor posuere proin blandit accumsan senectus netus nullam curae, ornare laoreet adipiscing luctus mauris adipiscing pretium eget fermentum, tristique lobortis est ut metus lobortis tortor tincidunt himenaeos habitant quis dictumst proin odio sagittis purus mi, nec taciti vestibulum quis in sit varius lorem sit metus mi.</p>
                            <p>Dolor posuere proin blandit accumsan senectus netus nullam curae, ornare laoreet adipiscing luctus mauris adipiscing pretium eget fermentum, tristique lobortis est ut metus lobortis tortor tincidunt himenaeos habitant quis dictumst proin odio sagittis purus mi, nec taciti vestibulum quis in sit varius lorem sit metus mi.</p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-default" type="button" data-dismiss="modal">Close</button>
                        <button class="btn btn-sm btn-primary" type="button" data-dismiss="modal"><i class="fa fa-check"></i> I agree</button>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?php echo $champ->assets_folder; ?>/js/jquery.min.js"></script>
        <script src="<?php echo $champ->assets_folder; ?>/js/bootstrap.min.js"></script>
        <script src="<?php echo $champ->assets_folder; ?>/js/app.js"></script>
    </body>
</html>