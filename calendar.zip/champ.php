<?php require_once 'champ.calendar.php'; ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Calendar</title>
<style>
*,th{text-align:center !important;}
table{table-layout: fixed;margin:100px 0;}
.past{color:#ccc;}
.future{color:#333;}
.end{color:#f00;}
.current{font-weight:700;}
</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
</head>
<body>
	<div class="container">
		<div class="col-md-6 col-md-offset-3">
			<?php
				$cal = new Calendar;
				echo $cal->show();
			?>
		</div>
	</div>
</body>
</html>