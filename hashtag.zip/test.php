<?php
$servername = "localhost";
$username 	= "root";
$password 	= "";

try {
    $conn = new PDO("mysql:host=$servername;dbname=one", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully";
}
catch(PDOException $e){
    echo "Connection failed: " . $e->getMessage();
}

function add($name,$phone,$email){
	try {
		global $conn;
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$stmt = $conn->prepare("INSERT INTO members (name, phone, email, modified) VALUES (:name, :phone, :email, NOW())");
		$stmt->bindParam(":name", $name); 
		$stmt->bindParam(":phone", $phone); 
		$stmt->bindParam(":email", $email); 
		$stmt->execute();
		echo "New record created successfully";
	}
	catch(PDOException $e){
		$e->getMessage();
	}
	$conn = null;
}
if(isset($_POST['submit'])){
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	add($name,$phone,$email);
}
?>
<form method="POST">
	<input type="text" name="name" placeholder="Name" />
	<input type="text" name="phone" placeholder="Phone" />
	<input type="text" name="email" placeholder="Email" />
	<input type="submit" name="submit"/>
</form>