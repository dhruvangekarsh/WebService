<?php

require  '../vendor/autoload.php';
 
/*$app->get('/', function ($request, $response, $args) {
 $response->write("Welcome: This is AlphansoTech Tutorial Guide");
 return $response;
});
 
$app->get('/friends', function ($request, $response, $args) {
 $response->write("Hello Friends!");
 return $response;
});*/
 
require '../lib/mysql.php';

$app = new \Slim\App; 
 
$app->get('/users', 'get_users');
 
$app->run();
 
function get_users() {
    $db = connect_db();
    $sql = "SELECT * FROM users";
    $exe = $db->query($sql);
    $data = $exe->fetch_all(MYSQLI_ASSOC);
    $db = null;
    echo json_encode($data);
}
 
 
$app->run();