<?php
if(isset($_GET["tag"])){
	$tag = preg_replace('#[^a-z0-9_]#i', '', $_GET["tag"]);
	// $tag is now sanitized and ready for database queries here
	//$fulltag = "#".$tag;
	$fulltag = $tag;
	echo $fulltag;
	echo "<br/><br/><br/>";
}

$con = new mysqli('localhost','root','','one');

$query = $con->query("SELECT * FROM posts WHERE content LIKE '%$tag%'") or die($con->error);

while($data = $query->fetch_object()){
	echo $data->title.'<br/>';
}


?>