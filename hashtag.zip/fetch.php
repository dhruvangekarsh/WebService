<?php

$conn = new mysqli('localhost','root','','one');

function convertHashtags($str){
	$regex = "/#+([a-zA-Z0-9_]+)/";
	$str = preg_replace($regex, '<a href="function.php?tag=$1">$0</a>', $str);
	return($str);
}


$query = $conn->query("SELECT * FROM posts") or die($conn->error);
while($data = $query->fetch_object()){
	echo $data->title." => ".convertHashtags($data->content)."<br/><br/>";
}

?>